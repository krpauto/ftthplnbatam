// Create an instance of Notyf
var notyff = new Notyf();

setTimeout(function() {
	notyff.confirm('Selamat datang, Administrator Bencana!!');
}, 500);
