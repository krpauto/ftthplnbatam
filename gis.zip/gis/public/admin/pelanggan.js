
$(document).ready(function () {
    $('#formsimpandaneditpelanggan').hide();

    // pelanggan
    /*--first time load--*/
    ajaxlist(page_url = false);

    /*-- Search keyword--*/
    $(document).on('keyup', "#search_key", function (event) {
        ajaxlist(page_url = false);
        event.preventDefault();

    });

    /*-- Reset Search--*/
    $(document).on('click', "#resetBtn", function (event) {
        $("#search_key").val('');
        ajaxlist(page_url = false);
        event.preventDefault();
    });

    /*-- Page click --*/
    $(document).on('click', ".uk-pagination li a", function (event) {
        var page_url = $(this).attr('href');
        ajaxlist(page_url);
        event.preventDefault();
    });

    /*-- create function ajaxlist --*/
    function ajaxlist(page_url = false) {
        var search_key = $("#search_key").val();
        var url = base_url + 'administrator/tampilPelanggan';
        var dataString = 'search_key=' + search_key;
        if (page_url == false) {
            var page_url = url;
        }

        $.ajax({
            type: "POST",
            url: page_url,
            data: dataString,
            beforeSend: function () {
                $('.loading').show();
            },
            success: function (response) {
                console.log(response);
                $('#ajaxPelanggan').html(response);
                $('.loading').fadeOut("slow");
            }
        });
    }
    // pelanggan

    $('body').on('click', '#tambahmodal', function (e) {
        e.preventDefault();
        $('#formsimpandaneditpelanggan').show().fadeIn(3000);
        $('#tampilpelanggansemua').hide().fadeOut(3000);

        $('#namapelanggan').val("");
        $('#lokasipelanggan').val("");
        $('#paketpelanggan').val("");
        $('#latitudepelanggan').val("");
        $('#longitudepelanggan').val("");

        $('#kategori').val("0");

        $('#simpandata').text('Simpan Data');
        $('#submiteditdata').attr("id", "submitdata");
        $("#uploadPreview").attr("src", base_url + "public/img/no.png");


    });

    $('body').on('click', '#formedit', function (e) {
        e.preventDefault();

        var id = $(this).data("id");
        var nama = $(this).data("nama");
        var lokasi = $(this).data("lokasi");
        var latitude = $(this).data("latitude");
        var longitude = $(this).data("longitude");
        var paket = $(this).data("paket");
        var kategori = $(this).data("kategori");



        $('#idpelanggan').val(id);
        $('#namapelanggan').val(nama);
        $('#lokasipelanggan').val(lokasi);
        $('#paketpelanggan').val(paket);
        $('#latitudepelanggan').val(latitude);
        $('#longitudepelanggan').val(longitude);
        $('#kategori').val(kategori);


        $('#formsimpandaneditpelanggan').show().fadeIn(3000);
        $('#tampilpelanggansemua').hide().fadeOut(3000);


        $('#simpandata').text('Edit pelanggan');
        $('#submitdata').attr("id", "submiteditdata");



    });





    $('body').on('submit', '#submitdata', function (e) {
        e.preventDefault();


        var nama = $('#namapelanggan').val();
        var lokasi = $('#lokasipelanggan').val();
        var paket = $('#paketpelanggan').val();
        var latitude = $('#latitudepelanggan').val();
        var longitude = $('#longitudepelanggan').val();
        var kategori = $('#kategori').val();


        if (nama == "") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> Nama masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#namapelanggan').focus();
        } else if (lokasi == "") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> Lokasi masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#lokasipelanggan').focus();


        } else if (paket == "") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> Paket masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#paketpelanggan').focus();
        } else if (latitude == "") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> latitude masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#latitudepelanggan').focus();


        } else if (longitude == "") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> longitude masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#longitudepelanggan').focus();

        } else if (kategori == "0") {
            UIkit.notification({
                message: '<span uk-icon="icon: close"></span> kategori masih Kosong!',
                status: 'danger',
                pos: 'top-right',
                timeout: 1000,
            });

            $('#kategori').focus();
        } else {
            $.ajax({
                url: base_url + 'savedatapelanggan',
                type: "post",
                data: new FormData(this),
                processData: false,
                contentType: false,
                cache: false,
                async: false,
                beforeSend: function () {
                    $("#simpandata").html("Loading...");
                },
                success: function (data) {
                    $("#simpandata").html("Simpan Pelanggan");
                    ajaxlist(page_url = false);
                    UIkit.notification({
                        message: '<span uk-icon="icon: check"></span> Data berhasil tersimpan!',
                        status: 'success',
                        pos: 'top-right',
                        timeout: 1000,
                    });
                    $('#formsimpandaneditpelanggan').hide().fadeOut(3000);
                    $('#tampilpelanggansemua').show().fadeIn(3000);
                }
            });

        }

    });

    $('body').on('click', '#hapusdata', function (e) {
        e.preventDefault();
        var id = $(this).data('id');

        swal({
            title: "Apakah Anda Yakin?",
            text: "akan terhapus permanen!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        })
            .then((willDelete) => {
                if (willDelete) {
                    $.ajax({
                        type: "POST",
                        url: base_url + "hapuspelanggan",
                        data: { id: id },
                        dataType: "text",
                        success: function (data) {
                            ajaxlist(page_url = false);
                        }
                    });
                    swal("Berhasil! Data pelanggan sudah terhapus!", {
                        icon: "success",
                    });
                } else {
                    swal("Data anda masih aman!");
                }
            });




    });
    $('body').on('submit', '#submiteditdata', function (e) {
        e.preventDefault();
        $.ajax({
            url: base_url + 'editdatapelanggan',
            type: "post",
            data: new FormData(this),
            processData: false,
            contentType: false,
            cache: false,
            async: false,
            beforeSend: function () {
                $("#simpandata").html("Loading...");
            },
            success: function (data) {
                ajaxlist(page_url = false);
                UIkit.notification({
                    message: '<span uk-icon="icon: check"></span> Data berhasil teredit!',
                    status: 'success',
                    pos: 'top-right',
                    timeout: 1000,
                });
                $('#formsimpandaneditpelanggan').hide().fadeOut(3000);
                $('#tampilpelanggansemua').show().fadeIn(3000);
                $('#simpandata').text('Simpan Data');
                $('#submiteditdata').attr("id", "submitdata");
            }
        });



    });

    $('#kembalikeawal').click(function (e) {
        e.preventDefault();

        $('#judulpelanggan').val("");

        $('#gbrpelanggan').val("");
        $('#idpelanggan').val("");

        $('#simpandata').text('Simpan Data');
        $('#submiteditdata').attr("id", "submitdata");
        $("#uploadPreview").attr("src", base_url + "public/img/no.png");
        $('#formsimpandaneditpelanggan').hide().fadeOut(3000);
        $('#tampilpelanggansemua').show().fadeIn(3000);

    });

});



