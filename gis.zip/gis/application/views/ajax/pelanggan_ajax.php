<div class="uk-overflow-auto">
    <table class="uk-table uk-table-justify uk-table-divider">
        <thead>
            <tr>
                <th>NO</th>
                <th>NAMA PELANGGAN</th>
                <th>LOKASI</th>
                <th>PAKET INTERNET</th>
                <th>LATITUDE</th>
                <th>LONGITUDE</th>
                <th>KATEGORI</th>

                <th>AKSI</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($pelanggan)) {
            ?>
                <?php
                $no = 1;
                foreach ($pelanggan as $p) {

                ?>

                    <tr>
                        <td width="40px"><?= $no ?></td>
                        <td><?= $p->namaPelanggan ?></td>
                        <td><?= $p->lokasiPelanggan ?></td>
                        <td><?= $p->paketPelanggan ?></td>
                        <td><?= $p->latitudePelanggan ?></td>
                        <td><?= $p->longitudePelanggan ?></td>
                        <td><?= $p->kategoriPelanggan ?></td>
                        <td>
                            <a href="#" class="uk-icon-link uk-margin-small-right" id="formedit" uk-icon="file-edit" data-id="<?= $p->idPelanggan ?>" data-nama="<?= $p->namaPelanggan ?>" data-lokasi="<?= $p->lokasiPelanggan ?>" data-latitude="<?= $p->latitudePelanggan ?>" data-longitude="<?= $p->longitudePelanggan ?>" data-paket="<?= $p->paketPelanggan ?>" data-kategori="<?= $p->kategoriPelanggan ?>"></a>
                            <a href="#" class="uk-icon-link" uk-icon="trash" id="hapusdata" data-id="<?= $p->idPelanggan ?>" data-nama="<?= $p->namaPelanggan ?>"></a>

                        </td>
                    </tr>
                <?php $no++;
                }
            } else {
                ?>
                <tr>
                    <td colspan="9" class="no-records">No records</td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

</div>
<ul class="uk-pagination" uk-margin-small-right>
    <?php echo $pagelinks ?>
</ul>